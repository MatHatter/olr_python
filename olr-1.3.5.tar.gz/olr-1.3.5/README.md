The olr function systematically evaluates multiple linear regression models by exhaustively considering all possible combinations of independent variables against the dependent variable. It then provides a statistical summary based on either the highest adjusted R-squared or R-squared value obtained from these models.

In the realm of model evaluation, both R-squared and adjusted R-squared serve as prominent metrics, each offering unique insights into the quality of the model fit. R-squared, while widely used, has a tendency to increase with the inclusion of any explanatory variable, regardless of its significance. This characteristic can potentially lead to the incorporation of unnecessary variables, contributing to overfitting issues.

To address this concern, adjusted R-squared penalizes the addition of superfluous variables, offering a more refined assessment of model fit. Within the olr function framework, the primary objective is to identify the model that best aligns with the underlying data, maximizing predictive accuracy without sacrificing model complexity. Thus, while adjusted R-squared provides valuable insights into model parsimony, the inclusion of R-squared alongside it ensures a comprehensive evaluation of model performance.

By considering both metrics, the olr function facilitates the identification of the most suitable model, striking a balance between explanatory power and complexity. This approach ensures that the selected model effectively captures the inherent relationships within the data while mitigating the risk of overfitting.


dataset = pd.read_csv('C:\Users\wfky1\OneDrive\Documents\PythonFolder\PythonOlr\olr_python_package\data\crudeoildata.csv') <br />
responseName = dataset[['OilPrices']] <br />
predictorNames = dataset[['SPX', 'RigCount', 'API', 'FieldProduction', 'RefinerNetInput', 'OperableCapacity', 'Imports', 'StocksExcludingSPR, 'NonCommercialLong', 'NonCommercialShort', 'CommercialLong', 'CommercialShort', 'TotalLong', 'TotalShort', 'NonReportablePositionsLong', 'NonReportablePositionsLShort', 'OpenInterest']] <br />

The TRUE or FALSE in the olr function, specifies either the adjusted R-squared or the R-squared regression summary, respectfully.

When responseName and predictorNames are None (NULL), then the first column in the dataset is set as the responseName and the remaining columns are the predictorNames.

Adjusted R-squared <br />
olr(datasetname, resvarname = None, expvarnames = None, adjr2 = "True")

R-squared <br />
olr(datasetname, resvarname = None, expvarnames = None, adjr2 = "False")

list of summaries <br />
olrmodels(datasetname, resvarname = None, expvarnames = None)

list of formulas <br />
olrformulas(datasetname, resvarname = None, expvarnames = None)

list of forumlas with the dependant variables in ascending order <br />
olrformulasorder(datasetname, resvarname = None, expvarnames = None)

the list of adjusted R-squared terms <br />
adjr2list(datasetname, resvarname = None, expvarnames = None)

the list of R-squared terms <br />
r2list(datasetname, resvarname = None, expvarnames = None)

An R version of this package olr is available on CRAN.